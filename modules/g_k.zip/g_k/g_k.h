/*
 * M-current from Horacio's equations 
 */

#include <default_gui_model.h>
#include <math.h>
#include <string>
#include "../include/DataLogger.cpp"

class g_k : public DefaultGUIModel
{

public:

    g_k(void);
    virtual ~g_k(void);

    virtual void execute(void);

protected:

    virtual void update(DefaultGUIModel::update_flags_t);

private:


    DataLogger data;
    
    double gk;
    double qtau;
    double Ehaks;
    double q;
    double Ek;

    int acquire;
    double maxt;
    double cellnum;
    string prefix;
    string info;
    double tcnt;
    double dt;
    vector<double> newdata;


};
