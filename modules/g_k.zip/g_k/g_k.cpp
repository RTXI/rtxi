/*
 * M-current from Acker et al 2003
 */

#include <g_k.h>
#include <math.h>


extern "C" Plugin::Object *createRTXIPlugin(void) {
    return new g_k();
}

static DefaultGUIModel::variable_t vars[] = {
    {
        "Vm",
        "Membrane Volprefixe (in mV)",
        DefaultGUIModel::INPUT,
    },
    {
        "Iout",
        "Injected current (in Amps)",
        DefaultGUIModel::OUTPUT,
    },
    {
        "GK",
        "Maximal Postassium Conductance",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "Acquire?",
        "1 for yes, 0 for no",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::UINTEGER,
    },
    {
        "Record Len (sec)",
        "",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "Cell (#)",
        "",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "File Prefix",
        "",
        DefaultGUIModel::PARAMETER //| DefaultGUIModel::DOUBLE,
    },
    {
        "File Info",
        "",
        DefaultGUIModel::PARAMETER //| DefaultGUIModel::DOUBLE,
    },

};

static size_t num_vars = sizeof(vars)/sizeof(DefaultGUIModel::variable_t);

g_k::g_k(void)
    : DefaultGUIModel("M-Current (IKs)",::vars,::num_vars) {

        newdata.push_back(0);
        newdata.push_back(0);
        newdata.push_back(0);

        dt = RT::System::getInstance()->getPeriod()*1e-6;
        gk = 0.0;
        Ek = -90;
        qtau = 90;
        Ehaks = -32;
        q = 0.0;

        acquire = 0;
        maxt = 0.0;
        cellnum = 0;
        prefix = "IK";
        info = "n/a";

        update(INIT);
        refresh();
}

g_k::~g_k(void) {}

void g_k::execute(void) {

    int myacq = (int)acquire;
    double Iout = 0.0;

    // input in V, convert to mV
    double Vm = input(0) * 1e3 - 10; //Assuming 10 mV junction potential

    double qinf = 1.0 / (1.0 + exp(-(Vm - Ehaks) / 6.5));

    // euler solve this thing
    q = q + dt * ((qinf - q) / qtau); 
    
    // nS * mV = pA (output amps)
    Iout = gk * q * (Vm - Ek) * 1e-12;
    output(0) = Iout;

    // acquire data
    if (myacq == 1 && tcnt < maxt) {
        newdata[0] = tcnt;
        newdata[1] = Vm;
        newdata[2] = Iout;
        data.insertdata(newdata);
        tcnt += dt/1000;
    }

    if (myacq == 1 && tcnt >= maxt) {
        data.writebuffer(prefix, info);
        data.resetbuffer();

        tcnt = 0;

        acquire = 0;
        setParameter("Acquire?", 0.0);
        refresh();
    }
}

void g_k::update(DefaultGUIModel::update_flags_t flag) {
    switch(flag) {
        case INIT:
            setParameter("GK",gk);

            setParameter("Acquire?",acquire);
            setParameter("Record Len (sec)",maxt);
            setParameter("Cell (#)",cellnum);
            setParameter("File Prefix", prefix);
            setParameter("File Info", info);

            tcnt = 0.0;

            break;
        case MODIFY:
            gk = getParameter("GK").toDouble();

            acquire = getParameter("Acquire?").toUInt();
            maxt = getParameter("Record  Len (sec)").toDouble();
            cellnum = getParameter("Cell (#)").toDouble();
            prefix = getParameter("File Prefix").data();
            info = getParameter("File Info").data();

            data.newcell((int)cellnum);
            data.resetbuffer();
            tcnt = 0;

            break;
        case PERIOD:
            dt = RT::System::getInstance()->getPeriod()*1e-6;
        case PAUSE:
            output(0) = 0.0;
            break;
        default:
            break;
    }
}
