/*
 * Copyright (C) 2006 Weill Medical College of Cornell University
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <math.h>
#include <PSG.h>
#include <stdio.h>

extern "C" Plugin::Object *createRTXIPlugin(void) {
    return new PSG();
}

static DefaultGUIModel::variable_t vars[] = {
    {
        "State",
        "State (0 - 4)",
        DefaultGUIModel::INPUT,
    },
    {
        "Vm",
        "V",
        DefaultGUIModel::INPUT,
    },
    {
        "Current",
        "A",
        DefaultGUIModel::OUTPUT,
    },
    {
        "Rp",
        "V",
        DefaultGUIModel::OUTPUT,
    },
    {
        "Delay",
        "s",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "PSGRiseTime",
        "ms",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "PSGFallTime",
        "ms",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "PSGScalar",
        "Max G pS",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },
    {
        "PSGRp",
        "V",
        DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE,
    },    
    {
        "G",
        "Siemans",
        DefaultGUIModel::STATE,
    },  
};

static size_t num_vars = sizeof(vars)/sizeof(DefaultGUIModel::variable_t);

PSG::PSG(void)
    : DefaultGUIModel("PSG",::vars,::num_vars), Delay(0), PSGRise(2.61e-3), PSGFall(6.23e-3), PSGScalar(10), PSGRp(0){
    update(INIT);
    TIME = -1e10;
    for(iHist=0; iHist<HIST_LEN; iHist++) history[iHist]=-1e-10;

    refresh();
}

PSG::~PSG(void) {
  //delete[] PSGTrace;
}


void PSG::SetPSG(double *&adEPSP, double dEPSPRise, double dEPSPFall, double dAqRate)
{ 
	int i;
	double dMax = -10000000.0;
	TraceLen = (int)(6.0*dEPSPFall/dAqRate);
	if(TraceLen<1) TraceLen = 1;
	printf("PSG TraceLen = %d\n", TraceLen);

	//delete[] adEPSP;
	adEPSP = new double [TraceLen];
	
	for(i=0; i<TraceLen; i++)
	{ 
		adEPSP[i] = exp(-((i+1)*dAqRate)/(dEPSPFall)) -	
			exp(-((i+1)*dAqRate)/(dEPSPRise)); 
		if(adEPSP[i] > dMax) dMax = adEPSP[i];
	} 
	
	for(i=0; i<TraceLen; i++) 
	{ 
		adEPSP[i] /= dMax; 
	        //printf("%d, %f\n", i, adEPSP[i]);
	} 
} 


void PSG::execute(void) {

  //update history for the number of simultaneous synaptic inputs;
  if(input(0)==1)
  {
    //dStimTime=TIME;
    history[lSpikeCount%HIST_LEN] = TIME;
    lSpikeCount ++;
  }

  //calculate the output conductnce and current;
  G = 0;
  dOutputCurrent=0;
  for(iHist=0; iHist<HIST_LEN; iHist++)
    {
      if(TIME-history[iHist] >= Delay)
	{
	  m_iCount = (int)((TIME-history[iHist]-Delay)/dDeltaTSec);
	  
	  if(m_iCount < TraceLen && m_iCount>=0)
	    {
	      G += PSGTrace[m_iCount];
	      //if(m_iCount==1) printf("%d,%f\n",m_iCount, dOutputCurrent);
	    }
	}
    }
  dOutputCurrent = PSGScalar * G * (PSGRp - input(1));
  output(0) = dOutputCurrent*1e-12;
  output(1) = PSGRp;
  TIME+=dDeltaTSec;
  return;
}

void PSG::update(DefaultGUIModel::update_flags_t flag) {
    switch(flag) {
    	
      case INIT:
	setState("G",G);
          setParameter("Delay",Delay);
          setParameter("PSGRiseTime",PSGRise);
          setParameter("PSGFallTime",PSGFall);
          setParameter("PSGScalar",PSGScalar);
          setParameter("PSGRp",PSGRp);
 
          SetPSG(PSGTrace, PSGRise, PSGFall, RT::System::getInstance()->getPeriod()*1e-9);
 
         break;
          
          
      case MODIFY:

          Delay = getParameter("Delay").toDouble();
          PSGRise = getParameter("PSGRiseTime").toDouble();
          PSGFall = getParameter("PSGFallTime").toDouble();
          PSGScalar = getParameter("PSGScalar").toDouble();
          PSGRp = getParameter("PSGRp").toDouble();
 
          SetPSG(PSGTrace, PSGRise, PSGFall, RT::System::getInstance()->getPeriod()*1e-9);
           
          break;

    case PERIOD:
          SetPSG(PSGTrace, PSGRise, PSGFall, RT::System::getInstance()->getPeriod()*1e-9);
      default:
          break;
    }
    dDeltaTSec = RT::System::getInstance()->getPeriod()*1e-9;
}
