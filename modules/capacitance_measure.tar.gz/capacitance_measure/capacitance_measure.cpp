#include <capacitance_measure.h>

#include <cmath>

#include <gsl/gsl_linalg.h>

#define DATA_POINTS 1000

extern "C" Plugin::Object *
createRTXIPlugin(void) {
  return new CapacitanceMeasure();
}

static DefaultGUIModel::variable_t vars[] =
  {
    { "Iapp", "A", DefaultGUIModel::INPUT, },
    { "Vcommand", "V", DefaultGUIModel::OUTPUT, },
    { "Vhold", "mV", DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE, },
    { "Vpp", "mV", DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE, },
    { "Duration", "ms", DefaultGUIModel::PARAMETER | DefaultGUIModel::DOUBLE, },
    { "Cm", "Membrane Capacitance pF", DefaultGUIModel::STATE, },
    { "Rm", "Membrane Resistance MOhm", DefaultGUIModel::STATE, },
    { "Ra", "Access Resistance MOhm", DefaultGUIModel::STATE, }, };

static size_t num_vars = sizeof(vars) / sizeof(vars[0]);

CapacitanceMeasure::CapacitanceMeasure(void) :
  DefaultGUIModel("Capacitance Measurement", ::vars, ::num_vars) {
  Vhold = -60.0;
  Vpp = 5.0;
  duration = 4.0;

  setParameter("Vhold", Vhold);
  setParameter("Vpp", Vpp);
  setParameter("Duration", duration);

  Cm = Rm = Ra = 0.0;

  data_size = 2 * duration / (RT::System::getInstance()->getPeriod() * 1e-6);
  data = new double[data_size];
  for (size_t i = 0; i < data_size; ++i)
    data[i] = 0.0;

  count = 0;
  idx = 0;

  setState("Cm", Cm);
  setState("Rm", Rm);
  setState("Ra", Ra);
}

CapacitanceMeasure::~CapacitanceMeasure(void) {
  setActive(false);
  delete[] data;
}

void
CapacitanceMeasure::execute(void) {
  if (idx < data_size / 2)
    output(0) = 1e-3 * (Vhold + Vpp / 2);
  else
    output(0) = 1e-3 * (Vhold - Vpp / 2);

  data[idx] += input(0);

  if (++idx >= data_size) {
    idx = 0;
    ++count;
    if (count == DATA_POINTS) {

      for (size_t i = 0; i < data_size; ++i)
        data[i] /= DATA_POINTS;

      double I1 = 0.0;
      for (size_t i = static_cast<size_t> (round(data_size / 2 - ceil(data_size / 8))); i < data_size / 2; ++i)
        I1 += data[i];
      I1 /= ceil(data_size / 8);

      double I2 = 0.0;
      for (size_t i = static_cast<size_t> (round(data_size - ceil(data_size / 8))); i < data_size; ++i)
        I2 += data[i];
      I2 /= ceil(data_size / 8);

      double dt = RT::System::getInstance()->getPeriod() * 1e-6;

      double Q11;
      double tau1;
      {
        Q11 = 0.0;
        for (size_t i = 0; i < data_size / 2 - 1; ++i)
          Q11 += dt * 1e-3 * (data[i] + data[i + 1] - 2 * I1) / 2;
        Q11 = fabs(Q11);

        size_t xi = 0;
        for (; data[xi] <= data[xi + 1]; ++xi)
          ;

        double sy = 0.0;
        double Y = data[xi];
        double SY = sy;
        double tSY = 0.0;
        double YSY = data[xi] * sy;
        double SYSY = sy * sy;
        double t = 0.0;
        double tt = 0.0;
        double Yt = 0.0;
        for (size_t i = xi + 1; i < data_size / 2; ++i) {
          sy += dt * 1e-3 * (data[i - 1] + data[i]) / 2;

          Y += data[i];
          SY += sy;
          tSY += (i - xi) * dt * 1e-3 * sy;
          YSY += data[i] * sy;
          SYSY += sy * sy;
          t += (i - xi) * dt * 1e-3;
          tt += ((i - xi) * dt * 1e-3) * ((i - xi) * dt * 1e-3);
          Yt += (i - xi) * dt * 1e-3 * data[i];
        }

        double A[3 * 3] =
          { data_size / 2 - xi, SY, t, SY, SYSY, tSY, t, tSY, tt, };
        double B[3] =
          { Y, YSY, Yt, };
        double V[3 * 3];
        double S[3];
        double x[3];

        gsl_matrix_view a = gsl_matrix_view_array(A, 3, 3);
        gsl_matrix_view b = gsl_matrix_view_array(V, 3, 3);
        gsl_vector_view c = gsl_vector_view_array(S, 3);
        gsl_vector_view d = gsl_vector_view_array(x, 3);
        gsl_vector_view e = gsl_vector_view_array(B, 3);

        gsl_linalg_SV_decomp(&a.matrix, &b.matrix, &c.vector, &d.vector);
        gsl_linalg_SV_solve(&a.matrix, &b.matrix, &c.vector, &e.vector, &d.vector);
        tau1 = fabs(1.0 / x[1]);
      }

      double Q12;
      double tau2;
      {
        Q12 = 0.0;
        for (size_t i = data_size / 2; i < data_size; ++i)
          Q12 += dt * 1e-3 * (data[i] + data[i + 1] - 2 * I2) / 2;
        Q12 = fabs(Q12);

        size_t xi = data_size / 2;
        for (; data[xi] >= data[xi + 1]; ++xi)
          ;

        double sy = 0.0;
        double Y = data[xi];
        double SY = sy;
        double tSY = 0.0;
        double YSY = data[xi] * sy;
        double SYSY = sy * sy;
        double t = 0.0;
        double tt = 0.0;
        double Yt = 0.0;
        for (size_t i = xi + 1; i < data_size; ++i) {
          sy += dt * 1e-3 * (data[i - 1] + data[i]) / 2;

          Y += data[i];
          SY += sy;
          tSY += (i - xi) * dt * 1e-3 * sy;
          YSY += data[i] * sy;
          SYSY += sy * sy;
          t += (i - xi) * dt * 1e-3;
          tt += ((i - xi) * dt * 1e-3) * ((i - xi) * dt * 1e-3);
          Yt += (i - xi) * dt * 1e-3 * data[i];
        }

        double A[3 * 3] =
          { data_size - xi, SY, t, SY, SYSY, tSY, t, tSY, tt, };
        double B[3] =
          { Y, YSY, Yt, };
        double V[3 * 3];
        double S[3];
        double x[3];

        gsl_matrix_view a = gsl_matrix_view_array(A, 3, 3);
        gsl_matrix_view b = gsl_matrix_view_array(V, 3, 3);
        gsl_vector_view c = gsl_vector_view_array(S, 3);
        gsl_vector_view d = gsl_vector_view_array(x, 3);
        gsl_vector_view e = gsl_vector_view_array(B, 3);

        gsl_linalg_SV_decomp(&a.matrix, &b.matrix, &c.vector, &d.vector);
        gsl_linalg_SV_solve(&a.matrix, &b.matrix, &c.vector, &e.vector, &d.vector);
        tau2 = fabs(1.0 / x[1]);
      }

      double tau = (tau1 + tau2) / 2.0;

      double Q1 = (Q11 + Q12) / 2.0;
      double Q2 = fabs(I1 - I2) * tau;
      double Qt = Q1 + Q2;

      double Rt = Vpp * 1e-3 / fabs(I1 - I2);

      Ra = tau * Vpp * 1e-3 / Qt;
      Rm = Rt - Ra;
      Cm = Qt * Rt / (Vpp * 1e-3 * Rm);

      Ra = round(Ra * 1e-6 * 10) / 10;
      Rm = round(Rm * 1e-6 * 10) / 10;
      Cm = round(Cm * 1e12 * 10) / 10;

      output(0) = 0.0;
      setActive(false);
    }
  }
}

void
CapacitanceMeasure::update(DefaultGUIModel::update_flags_t flags) {
  if (flags | MODIFY) {
    Vhold = getParameter("Vhold").toDouble();
    Vpp = getParameter("Vpp").toDouble();
    duration = getParameter("Duration").toDouble();
    count = 0;
    idx = 0;

    size_t new_data_size = 2 * duration / (RT::System::getInstance()->getPeriod() * 1e-6);
    if (new_data_size != data_size) {
      delete[] data;
      data_size = new_data_size;
      data = new double[data_size];
    }
    for (size_t i = 0; i < data_size; ++i)
      data[i] = 0.0;
  } else if (flags | PERIOD) {
    delete[] data;
    data_size = 2 * duration / (RT::System::getInstance()->getPeriod() * 1e-6);
    data = new double[data_size];
    for (size_t i = 0; i < data_size; ++i)
      data[i] = 0.0;
    count = 0;
    idx = 0;
  } else if (flags | PAUSE) {
    output(0) = 0.0;
  } else if (flags | UNPAUSE) {
    for (size_t i = 0; i < data_size; ++i)
      data[i] = 0.0;
    count = 0;
    idx = 0;
  }
}
