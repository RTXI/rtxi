#ifndef CAPACITANCE_MEASURE_H
#define CAPACITANCE_MEASURE_H

#include <default_gui_model.h>

class CapacitanceMeasure : public DefaultGUIModel {

  Q_OBJECT

  public:

    CapacitanceMeasure(void);
    ~CapacitanceMeasure(void);

    void
    execute(void);

  private:

    void
    update(DefaultGUIModel::update_flags_t);

    size_t count;

    size_t idx;
    double *data;
    size_t data_size;

    double Vhold;
    double Vpp;
    double duration;

    double Cm;
    double Rm;
    double Ra;

}; // class CapacitanceMeasure

#endif // CAPACITANCE_MEASURE_H
