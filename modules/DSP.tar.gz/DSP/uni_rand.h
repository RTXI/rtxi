//
//  File = uni_rand.h
//
#ifndef _UNI_RAND_H_
#define _UNI_RAND_H_

float UniformRandom(long* seed);
double DoubleUniformRandom(long* seed);

#endif      
