//
//  File = sd_theor.h
//

#ifndef _SD_THEOR_H_
#define _SD_THEOR_H_

void SteepestDescentTheoretic( double start_pt_0,
                               double start_pt_1,
                               double mu,
                               int num_pts,
                               double min_dist);


#endif
