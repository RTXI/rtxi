//
//  File = gausrand.h
//
#ifndef _GAUSRAND_H_
#define _GAUSRAND_H_

double GaussRandom(long* seed);

#endif      
