//
//  File = sincsqrd.h
//

#ifndef _SINCSQRD_H_ 
#define _SINCSQRD_H_

double sinc_sqrd(double x);

#endif
