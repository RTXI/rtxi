//
//  File = sinc.h
//

#ifndef _SINC_H_ 
#define _SINC_H_

double sinc(double x);

#endif
