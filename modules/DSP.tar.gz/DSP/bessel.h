/*
 * Bessel function of the first kind and zero order
 */

#ifndef _BESSEL_H_ 
#define _BESSEL_H_

double bessel_I_zero(double x);

#endif
