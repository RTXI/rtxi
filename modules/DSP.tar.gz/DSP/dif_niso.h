//
// File = dif_niso.h
//
#ifndef _DIF_NISO_H_
#define _DIF_NISO_H_  

#include "complex.h"

void FftDifNiso( complex* array, int fft_size); 
 
#endif // _DIF_NISO_H_