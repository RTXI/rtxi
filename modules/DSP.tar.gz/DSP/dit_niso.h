//
// File = dit_niso.h
//
#ifndef _DIT_NISO_H_
#define _DIT_NISO_H_  

#include "complex.h"

void FftDitNiso( complex* array, int fft_size); 
 
#endif // _DIT_NISO_H_