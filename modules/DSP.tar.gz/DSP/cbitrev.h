//
// file = cbitrev.h
//

#ifndef _CBITREV_H
#define _CBITREV_H

#include "complex.h"

void ComplexBitReverse(complex *array, int size);

#endif //_CBITREV_H