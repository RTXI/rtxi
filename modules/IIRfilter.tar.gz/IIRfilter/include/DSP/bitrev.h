//
//  file = bitrev.h
//
#ifndef _BITREV_H
#define _BITREV_H

int bitrev( int in_val, int num_bits);

#endif // _BITREV_H