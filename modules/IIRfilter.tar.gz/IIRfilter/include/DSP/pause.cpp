//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//  File = pause.cpp
//

#include <iostream>

void pausewait(void)
{
int i;
std::cout << "enter any digit to continue" << std::endl;
std::cin >> i;
}
