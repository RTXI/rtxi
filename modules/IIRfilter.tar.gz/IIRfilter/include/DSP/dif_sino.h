//
// File = dif_sino.h
//
#ifndef _DIF_SINO_H_
#define _DIF_SINO_H_  

#include "complex.h"

void FftDifSino( complex* array, int fft_size); 
 
#endif // _DIF_SINO_H_