//
//  File = log2.h
//

#ifndef _LOG2_H_ 
#define _LOG2_H_

int
ilog2(int value_inp);

#endif
