/*
 * Acosh, inverse hyperbolic cosine
 */

#ifndef _ACOSH_H_ 
#define _ACOSH_H_

double acosh(double x);

#endif
