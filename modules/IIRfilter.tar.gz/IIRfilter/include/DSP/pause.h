//
// File = pause.h
//
#ifndef _PAUSE_H_
#define _PAUSE_H_  

void pausewait(void);
#endif 
