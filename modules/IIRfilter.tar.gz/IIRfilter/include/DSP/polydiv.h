//
// File = polydiv.h
//
#ifndef _POLYDIV_H_
#define _POLYDIV_H_  

void polydiv( complex *dvnd,
              int dvnd_deg,
              complex *dvsr,
              int dvsr_deg,
              complex *quot,
              complex *remndr);

#endif 