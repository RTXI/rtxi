//
// File = anlgfilt.h
//
#ifndef _ANLGFILT_H_
#define _ANLGFILT_H_  

#include "numinteg.h"
#include "poly.h"

class AnalogFilter
{
public: 

  //  constructor
  AnalogFilter( );
  
  virtual double Run( double );

private:

}; 
#endif 