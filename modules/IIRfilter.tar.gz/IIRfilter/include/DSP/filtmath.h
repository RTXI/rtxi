//
// file = filtmath.h
//

#ifndef FILTMATH_H
#define FILTMATH_H

double DSubInf(double delta_p, double delta_s);

#endif //FILTMATH_H