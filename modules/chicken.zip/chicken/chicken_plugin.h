
/* 
 * chicken_plugin.h
 *
 *
 *
 * Version $Revision: 1.4 $
 *
 */


#ifndef _CHICKEN_PLUGIN_H
#define _CHICKEN_PLUGIN_H

#include <string>
#include <string.h>
#include <pthread.h>

#include <io.h>
#include <plugin.h>
#include <workspace.h>

#include <plugins/performance_measurement/performance_measurement.h>
#include <plugins/data_recorder/data_recorder.h>


typedef unsigned long flags_t;

class ChickenWorkspace
{

    static const flags_t INPUT  = 0x1;
    static const flags_t OUTPUT = 0x2;
    static const flags_t PARAMETER  = 0x4;
    static const flags_t STATE  = 0x8;

public:
    ChickenWorkspace(Workspace::Instance *);
    ChickenWorkspace(void);

    const char *getWorkspaceName (void);
    size_t getCount(flags_t type);
    const char *getName(flags_t type, size_t index);
    double getValue(flags_t type,size_t index);
    void setValue(size_t index,double value);
    void addRecordVar (flags_t type,size_t index);
    void removeRecordVar (flags_t type,size_t index);
    void toggleRecord (bool f);

private:

    Workspace::Instance *workspace;
    DataRecorder::Panel *recorder;
};


class ChickenPlugin:  public ::Plugin::Object, public Event::Handler
{

public:
    ChickenWorkspace *getWorkspace(char *name);

    static ChickenPlugin *getInstance(void);
    
    static pthread_t tid;
    static int initialized;

    int getInputFileno (void);
    int getOutputFileno (void);

    int setPeriod (long);

private:
    ChickenPlugin(void);
    ~ChickenPlugin(void);
    ChickenPlugin(const ChickenPlugin &) {};
    ChickenPlugin &operator=(const ChickenPlugin &) { return *getInstance(); };

    void run(void);

    int input_fd;
    int output_fd;

    static ChickenPlugin *instance;
    Workspace::Manager *wm;
};

size_t writeInput (unsigned char *buf, size_t size);
size_t readOutput (unsigned char *buf, size_t size);

ChickenWorkspace *findChickenWorkspace (char *name);

class ChickenTiming
{
public:
     void timing(void);
     ChickenTiming(PerformanceMeasurement::Plugin *);
	 

private:
     PerformanceMeasurement::Plugin *pm;
};

ChickenTiming *getChickenTiming (void);

void startTiming (void);


#endif /* _CHICKEN_PLUGIN_H */

/*
 * $Id: chicken_plugin.h,v 1.4 2007/02/27 20:13:38 ivan_raikov Exp $
 *
 * 
 * $Log: chicken_plugin.h,v $
 * Revision 1.4  2007/02/27 20:13:38  ivan_raikov
 * - Update to the Chicken Scheme and Python bindings to support
 *   setPeriod with long long argument instead of double.
 * - Update to the build system to support relative paths for building
 *   models, and to use realpath(1) to supply libtool with the
 *   corresponding absolute paths.
 *
 * Revision 1.3  2007/02/12 17:46:53  ivan_raikov
 * Incorporated the Python plugin and many changes to the build system, the
 * console interface, and the Debian packages.
 *
 * Revision 1.2  2006/11/29 02:00:52  ivan_raikov
 * Numerous updates related to the RTXI console and the Chicken plugin.
 *
 * Revision 1.1  2006/11/25 22:59:02  ivan_raikov
 * - Added qonsole, a terminal console based on Qt.
 * - Added a scripting interface via a Chicken Scheme wrapper.
 *
 *
 */
