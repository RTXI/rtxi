/* -*-c-file-style: "bsd" -*- */

/* 
 * chicken_plugin.cpp
 *
 *
 *
 * Version $Revision: 1.8 $
 *
 */

#include <string>
#include <stdio.h>

#include <chicken.h>

#ifndef _CHICKEN_PLUGIN_H
#include <chicken_plugin.h>
#endif

#ifdef QONSOLE
#include <console.h>
#endif
#include <cmdline.h>
#include <plugins/performance_measurement/performance_measurement.h>
#include <plugins/data_recorder/data_recorder.h>
#include <plugins/dynamo_model_loader/dynamo_model_loader.h>


extern "C" Plugin::Object *createRTXIPlugin(void *) 
{
	return ChickenPlugin::getInstance();
}


extern "C" void *chicken_run (void *arg)
{
     C_word x;

     DEBUG_MSG("chicken_run : starting\n");

     DEBUG_MSG("chicken_run : ChickenPlugin::initialized = %d\n", 
	       ChickenPlugin::initialized );

     if (ChickenPlugin::initialized == 0)
     {
	     CHICKEN_run((void*)C_toplevel);
	     ChickenPlugin::initialized = 1;
     }

     CHICKEN_eval_string("(rtxi-controller)", &x);

     DEBUG_MSG("chicken_run : end\n");

     return NULL;
}


/*
 *
 * Default constructor
 *
 */

ChickenPlugin::ChickenPlugin(void)
{
	DEBUG_MSG("ChickenPlugin::ChickenPlugin : starting\n");

	wm = Workspace::Manager::getInstance();
	
#ifdef QONSOLE
	int *fd;

	if ((fd = Console::getInstance()->requestIoFd()) == NULL)
	{
		DEBUG_MSG("ChickenPlugin::ChickenPlugin: unable to allocate I/O file descriptors\n");
		return;
	}

	input_fd      = dup(fd[1]);
	output_fd     = dup(fd[2]);

	Console::getInstance()->setTabLabel (fd[0],"RTXI Script");

	delete fd;
#else
	input_fd = dup(STDOUT_FILENO);
	output_fd = dup(STDIN_FILENO);
#endif

	DEBUG_MSG("ChickenPlugin::ChickenPlugin : input_fd = %d\n", input_fd);
	DEBUG_MSG("ChickenPlugin::ChickenPlugin : output_fd = %d\n", output_fd);

	run();

}

/*
 *
 * Destroys the object
 *
 */

ChickenPlugin::~ChickenPlugin(void)
{
	if (tid != 0) pthread_cancel(tid);
	close (input_fd);
	close (output_fd);
	ChickenPlugin::instance = NULL;
}


void ChickenPlugin::run (void)
{
	int status; 
	
	if (tid != 0)
	{
		pthread_cancel(tid);
	}

	if ((status = pthread_create (&tid, NULL, chicken_run, NULL)) != 0)
		return;
}

int ChickenPlugin::setPeriod (long period)
{
        return RT::System::getInstance()->setPeriod((long long)period);
}


struct cmp_t
{
	char *name;
	Workspace::Instance *x; 
};

void find (Workspace::Instance *w, cmp_t *ax)
{
	IO::Block *b;
	
	b = (IO::Block *)w;
	if (strcmp((b->getName()).c_str(), ax->name) == 0)
		ax->x = w;
}

ChickenWorkspace *ChickenPlugin::getWorkspace (char *name)
{
	struct cmp_t ax;
	
	ax.name = name;
	ax.x = NULL;
	
	wm->foreachWorkspace ((void (*)(Workspace::Instance*, void*))find, &ax);
	
	if (ax.x != NULL)
		return (new ChickenWorkspace(ax.x));
	else
		return (new ChickenWorkspace());
}

static Mutex mutex;
ChickenPlugin *ChickenPlugin::instance = NULL;

ChickenPlugin *ChickenPlugin::getInstance(void) 
{
    if(instance != NULL)
        return instance;

    Mutex::Locker lock(&::mutex);
    if(instance == NULL)
        instance = new ChickenPlugin();

    return instance;
}



const char *ChickenWorkspace::getWorkspaceName()
{
	return (((IO::Block *)workspace)->getName()).c_str();
}

ChickenWorkspace::ChickenWorkspace (Workspace::Instance *w)
{
	this->workspace = w;
	this->recorder = DataRecorder::Plugin::getInstance()->createDataRecorderPanel();
}

ChickenWorkspace::ChickenWorkspace (void)
{
	this->workspace = new Workspace::Instance("NULL",NULL,0);
	this->recorder = NULL;
}

size_t ChickenWorkspace::getCount(flags_t type)
{
	return workspace->getCount(type);
}

const char *ChickenWorkspace::getName(flags_t type, size_t index)
{
	return (workspace->getName(type,index)).c_str();
}

double ChickenWorkspace::getValue(flags_t type,size_t index)
{
	return workspace->getValue(type,index);
}

void ChickenWorkspace::setValue(size_t index,double value)
{
	workspace->setValue(index,value);
}
void ChickenWorkspace::addRecordVar (flags_t type,size_t index)
{
	if (recorder != NULL)
		recorder->addWorkspaceVar(workspace,type,index);
}

void ChickenWorkspace::removeRecordVar (flags_t type,size_t index)
{
	if (recorder != NULL)
		recorder->removeWorkspaceVar(workspace,type,index);
}

void ChickenWorkspace::toggleRecord (bool f)
{
	if (recorder != NULL)
		recorder->toggleRecord(f);
}

int ChickenPlugin::initialized = 0;

pthread_t ChickenPlugin::tid = 0;

int ChickenPlugin::getInputFileno (void)
{
	return input_fd;
}

int ChickenPlugin::getOutputFileno (void)
{
	return output_fd;
}

ChickenWorkspace *findChickenWorkspace (char *name)
{
	return ChickenPlugin::getInstance()->getWorkspace(name);
}

int setPeriod (long period)
{
        return ChickenPlugin::getInstance()->setPeriod(period);
}

size_t writeInput (unsigned char *buf, size_t size)
{
	int fd; size_t s;
	fd = ChickenPlugin::getInstance()->getInputFileno();
	s = write(fd,(void *)buf,size);
	return s;
}

size_t readOutput (unsigned char *buf, size_t size)
{
	int fd;  size_t s;
	fd = ChickenPlugin::getInstance()->getOutputFileno();
	memset(buf,0,size);
	s = read(fd,(void *)buf,size);
	return s;
}

int shellExecute (char *cmd)
{
	int status; 
	std::string cwd;

	if ((cwd=std::string(getcwd(NULL,0))) == NULL) return -1;

	std::string chwd = (std::string("cd ")) + cwd + (std::string("; "));
	std::string cmdline = chwd + (std::string(cmd));
	status = CmdLine::getInstance()->execute(cmdline);

	return status;
}

int changeCwd (char *path)
{
	int status; 
	
	status = chdir(path);

	return status;
}

void ChickenTiming::timing(void)
{
	pm->createPerformanceMeasurementPanel();
}

ChickenTiming::ChickenTiming(PerformanceMeasurement::Plugin *pm)
{
	this->pm = pm;
}

ChickenTiming *getChickenTiming (void)
{
	return new ChickenTiming (PerformanceMeasurement::Plugin::getInstance ());
}

void startTiming (void)
{
	getChickenTiming()->timing();
}

void loadModel (char *path)
{
	DynamoModelLoader::getInstance()->load(path);
}

/*
 * $Id: chicken_plugin.cpp,v 1.8 2007/02/27 20:13:38 ivan_raikov Exp $
 *
 * 
 * $Log: chicken_plugin.cpp,v $
 * Revision 1.8  2007/02/27 20:13:38  ivan_raikov
 * - Update to the Chicken Scheme and Python bindings to support
 *   setPeriod with long long argument instead of double.
 * - Update to the build system to support relative paths for building
 *   models, and to use realpath(1) to supply libtool with the
 *   corresponding absolute paths.
 *
 * Revision 1.7  2007/02/26 19:35:38  ivan_raikov
 * Fixed the setrate command to compute the period in nanoseconds
 * correctly.
 *
 * Revision 1.6  2007/02/12 17:46:53  ivan_raikov
 * Incorporated the Python plugin and many changes to the build system, the
 * console interface, and the Debian packages.
 *
 * Revision 1.5  2006/12/04 03:52:03  ivan_raikov
 * Introduced a fix to CmdLine to change the current directory to that of the
 * parent process before executing the shell command.
 *
 * Revision 1.4  2006/12/01 00:16:54  ivan_raikov
 * - Fixes to the Console class.
 * - Added the model command to the command interpreter.
 *
 * Revision 1.3  2006/11/30 00:17:49  ivan_raikov
 * Updates to use the RTXI console as stdin/stdout.
 *
 * Revision 1.2  2006/11/29 02:00:52  ivan_raikov
 * Numerous updates related to the RTXI console and the Chicken plugin.
 *
 * Revision 1.1  2006/11/25 22:59:02  ivan_raikov
 * - Added qonsole, a terminal console based on Qt.
 * - Added a scripting interface via a Chicken Scheme wrapper.
 *
 *
 */
