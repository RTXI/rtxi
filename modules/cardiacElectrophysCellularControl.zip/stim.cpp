/*
 * Copyright (C) 2004 Boston University
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stim.h>
#include <qhbox.h>
#include <math.h>
#include <string.h>
#include <qgridview.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qlineedit.h>
#include <qpixmap.h>
#include <qpushbutton.h>
#include <qpainter.h>
#include <qtimer.h>
#include <qvalidator.h>
#include <qtooltip.h>
#include <qvbox.h>
#include <main_window.h>
#include <rtfile.h>
#include <../plugins/am_amp_commander/am_amp_commander.h>

//#define __fancyControl

namespace {

    class SyncEvent : public RT::Event {

    public:

        int callback(void) { return 0; };

    }; // class SyncEvent

} // namespace

extern "C" Plugin::Object *createRTXIPlugin(void) {
    return new stim();
}

static stim::variable_t vars[] = {
    {
	"Vm",
	"Recorded membrane voltage",
	stim::INPUT,
    },
    {
	"Vout",
	"Applied membrane voltage",
	stim::OUTPUT,
    },
    {
        "Istim",
        "Stimulation current",
	stim::OUTPUT,
    },
    {
        "CameraCurrent",
        "output to camera to start data acquisition",
	stim::OUTPUT,
    },
    {
        "ShutterCurrent",
        "output to fluorescent lamp shutter",
	stim::OUTPUT,
    },
    {
        "ControlGain",
        "Gain of alternans control algorithm (gamma)",
        stim::PARAMETER | stim::DOUBLE,
    },
    {
        "controlGainAdaptation",
        "increment by which to adapt gain",
        stim::PARAMETER | stim::DOUBLE,
    },
    {
        "period1Threshold",
        "maximum alternans magniude (in sec) allowed to be considered at period-1.",
        stim::PARAMETER | stim::DOUBLE,
    },
    {
        "period1Beats",
        "number of beats below threshold necessary to be considered at period-1 (<20)",
        stim::PARAMETER | stim::DOUBLE,
    },
    {
	"measuredRMBP",
	"measured resting membrane potential (mV), set to 99999 to take RMBP dynamically",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
        "threshold",
        "Add this value (mV) to RMBP to get threshold level",
        stim::PARAMETER | stim::DOUBLE,
    },
    {
        "RepolPercent",
        "Percentage repolarization to use in calculating APD (as decimal)",
        stim::PARAMETER | stim::DOUBLE,
    },
    {
	"StimMag",
	"Amplitude of stimulus current (nA)",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"StimLength",
	"duration of stimulus pulse (ms)",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"StartBCL",
	"BCL at which ramping begins (ms)",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"finalBCL",
	"BCL at which cell is to be tested (ms)",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"rampStep",
	"ramp step size (ms)",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"BeatsPerStep",
	"Number of beats at each BCL",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"shutterOpenDuration",
	"how long the shutter will remain open when triggered (seconds)",
	stim::PARAMETER | stim::DOUBLE,
    },
    {
	"beatNum",
	"Current Beat Number",
	stim::STATE,
    },
    {	
	"BCLout",
	"current BCL (ms)",
	stim::STATE,
    },
    {
	"APDout",
	"APD of the current beat (sec)",
	stim::STATE,
    },
    {
	"alternansMagnitude",
	"(APD[n] - APD[n-1]) / 1000 (sec)",
	stim::STATE,
    },
    {
	"RMBPout",
	"measured RMBP",
	stim::STATE,
    },
    {
	"ControlGainOut",
	"current adaptive control gain",
	stim::STATE,
    },
    {
	"shutterOPENBeat",
	"Beat at which shutter will open",
	stim::STATE,
    },
    {
	"rampBeats",
	"Number of ramp beats in protocol",
	stim::STATE,
    },
};

static size_t num_vars = sizeof(vars)/sizeof(stim::variable_t);


//Constructor
stim::stim(void)

    : QWidget(MainWindow::getInstance()->centralWidget()), Workspace::Instance("stim",vars,num_vars) {

    setCaption(QString::number(getID())+" Stim");

    QBoxLayout *layout = new QVBoxLayout(this);

    QScrollView *sv = new QScrollView(this);
    sv->setResizePolicy(QScrollView::AutoOneFit);
    layout->addWidget(sv);

    QWidget *viewport = new QWidget(sv->viewport());
    sv->addChild(viewport);
    QGridLayout *scrollLayout = new QGridLayout(viewport,1,2);

    size_t nstate = 0, nparam = 0, nevent = 0;
    
    for(size_t i=0;i<num_vars;i++) {
        if(vars[i].flags & (PARAMETER | STATE | EVENT)) {
            param_t param;

            param.label = new QLabel(vars[i].name,viewport);
	    param.label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            scrollLayout->addWidget(param.label,parameter.size(),0);
            param.edit = new DefaultGUILineEdit(viewport);
	    param.edit->setAlignment(Qt::AlignLeft | Qt::AlignBottom);
            scrollLayout->addWidget(param.edit,parameter.size(),1);

            QToolTip::add(param.label,vars[i].description);
            QToolTip::add(param.edit,vars[i].description);

            if(vars[i].flags & PARAMETER) {
                if(vars[i].flags & DOUBLE) {
                    param.edit->setValidator(new QDoubleValidator(param.edit));
                    param.type = PARAMETER | DOUBLE;
                } else if(vars[i].flags & UINTEGER) {
                    QIntValidator *validator = new QIntValidator(param.edit);
                    param.edit->setValidator(validator);
                    validator->setBottom(0);
                    param.type = PARAMETER | UINTEGER;
                } else if(vars[i].flags & INTEGER) {
                    param.edit->setValidator(new QIntValidator(param.edit));
                    param.type = PARAMETER | INTEGER;
                } else
                    param.type = PARAMETER;
                param.index = nparam++;
                param.str_value = new QString;
                setData(PARAMETER,param.index,param.value = new double);
            } else 
                {
                    if(vars[i].flags & STATE) 
                        {
                            param.edit->setReadOnly(true);
                            param.type = STATE;
                            param.index = nstate++;
                        } else
                        {
                            if(vars[i].flags & EVENT) 
                                {
                                    param.edit->setReadOnly(true);
                                    param.type = EVENT;
                                    param.index = nevent++;
                                }
                        }
                }

            parameter[vars[i].name] = param;
        }
    }

    modeHeader = new QLabel(this);
    modeHeader->setFont(QFont("Courier",12));
    modeHeader->setAlignment(Qt::AlignCenter);
    modeHeader->setScaledContents(true);   
    QString modeHeaderString;
    modeHeaderString.sprintf("\n--AMPLIFIER MODE--");
    modeHeader->setText(modeHeaderString);

    ModeLabel = new QLabel(this);
    ModeLabel->setFont(QFont("Courier",32));
    ModeLabel->setAlignment(Qt::AlignCenter);
    ModeLabel->setScaledContents(true);   

    exptModeHeader = new QLabel(this);
    exptModeHeader->setFont(QFont("Courier",12));
    exptModeHeader->setAlignment(Qt::AlignCenter);
    exptModeHeader->setScaledContents(true);   
    QString exptModeHeaderString;
    exptModeHeaderString.sprintf("\n--EXPERIMENT MODE--");
    exptModeHeader->setText(exptModeHeaderString);

    QHBox *utilityBox = new QHBox(this);
    pauseButton = new QPushButton("Pause",utilityBox);
    pauseButton->setToggleButton(true);
    QObject::connect(pauseButton,SIGNAL(toggled(bool)),this,SLOT(pause(bool)));
    QPushButton *modifyButton = new QPushButton("Modify",utilityBox);
    QObject::connect(modifyButton,SIGNAL(clicked(void)),this,SLOT(modify(void)));
    QPushButton *unloadButton = new QPushButton("Unload",utilityBox);
    QObject::connect(unloadButton,SIGNAL(clicked(void)),this,SLOT(exit(void)));

    thresholdLabel = new QLabel(this);
    thresholdLabel->setFont(QFont("Courier",12));
    thresholdLabel->setAlignment(Qt::AlignCenter);
    thresholdLabel->setScaledContents(true);   

    QHBox *exptModeBox = new QHBox(this);
    thresholdTestButton = new QPushButton("Threshold Test", exptModeBox);
    thresholdTestButton->setToggleButton(true);
    QObject::connect(thresholdTestButton,SIGNAL(toggled(bool)),this,SLOT(toggleThresholdTest(bool)));
    paceButton = new QPushButton("Pace", exptModeBox);
    paceButton->setToggleButton(true);
    QObject::connect(paceButton,SIGNAL(toggled(bool)),this,SLOT(togglePace(bool)));
    
    exptLabel = new QLabel(this);
    exptLabel->setFont(QFont("Courier",12));
    exptLabel->setAlignment(Qt::AlignCenter);
    exptLabel->setScaledContents(true);   
    QString exptLabelString;
    exptLabelString.sprintf("\n--EXPERIMENTS--");
    exptLabel->setText(exptLabelString);

    QHBox *exptBox = new QHBox(this);
    toggleExp1Button = new QPushButton("ClampExp",exptBox);
    toggleExp1Button->setToggleButton(true);
    QObject::connect(toggleExp1Button,SIGNAL(toggled(bool)),this,SLOT(toggleExp1(bool)));
    toggleExp2Button = new QPushButton("PaceExp",exptBox);
    toggleExp2Button->setToggleButton(true);
    QObject::connect(toggleExp2Button,SIGNAL(toggled(bool)),this,SLOT(toggleExp2(bool)));

    cameraButton = new QPushButton("Camera",exptBox);
    cameraButton->setToggleButton(true);
    QObject::connect(cameraButton,SIGNAL(toggled(bool)),this,SLOT(toggleCameraButton(bool)));
    QPushButton *startExp4Button = new QPushButton("dynRest",exptBox);
    QObject::connect(startExp4Button,SIGNAL(clicked(void)),this,SLOT(startExp4(void)));

    QHBox *controlBox = new QHBox(this);
    controlButton = new QPushButton("Alternans Control",controlBox);
    controlButton->setToggleButton(true);
    QObject::connect(controlButton,SIGNAL(toggled(bool)),this,SLOT(toggleControl(bool)));
    
    exptInfoLabel = new QTextEdit(this);
    exptInfoLabel->setFont(QFont("Courier",12));
    exptInfoLabel->setAlignment(Qt::AlignCenter | Qt::AlignTop);
    exptInfoLabel->setReadOnly(true);	
    exptInfoLabel->setMaximumHeight(100);

    layout->addWidget(modeHeader);
    layout->addWidget(ModeLabel);
    layout->addWidget(exptModeHeader);
    layout->addWidget(exptModeBox);
    layout->addWidget(thresholdLabel);
    layout->addWidget(exptLabel);
    layout->addWidget(exptBox);
    layout->addWidget(controlBox);
    layout->addWidget(exptInfoLabel);
    layout->addWidget(utilityBox);

    QTimer *timer = new QTimer(this);
    timer->start(1000);
    QObject::connect(timer,SIGNAL(timeout(void)),this,SLOT(refresh(void)));

    show();

     // Initialize Parameters & Variables
    pace=false;	
    rampBeatCount=0;
    sampleStep=0;
    ClampCount=0;
    cycleNumber = 0;
    shutterOPENBeat = 99999;
    APD[0] = 0;
    APD[1] = 0;
    theta[0]=0;
    theta[1]=0;
    theta[2]=0;
    theta[3]=0;
    dVmax = 0;
    Vmax = -999;
    if (measuredRMBP==99999)
	RMBP = input(0);
    else
	RMBP = measuredRMBP / 1000;
    cycleLength = StartBCL;
    cameraRecording=false;
    shutterOpen=false;
    shutterCloseTime = 0;
    expt1InProgress=false;
    expt1Triggered=false;
    expt2InProgress=false;
    expt2Triggered=false;
    StartClampBeat=999999;
    StartControlBeat=999999;
    StopControlBeat=999999;
    aMagSum = 0;
    aMagCount = 0;
    period1Threshold=0.005;
    period1Beats=5;
    alternansControl=false;
    for (int ii=0; ii<20; ii++) previousAlternansMagnitude[ii]=0;
    controlGainAdaptation = 0.01;
    exptInfoLabel->clear();
    
    // thresholdDetection parameters
    thresholdDetection=false;


	// restitution protocol parameters:
	s1BCL = 500;
	numberS1Beats=20;
	restStopBCL=250;
	restInterval = 10;
	restitutionProtocol = false;

   
    // calculate number of ramp beats needed-- careful about non-integer results
    rampBeats = BeatsPerStep * ((StartBCL-finalBCL) / rampStep);
    if (rampBeats < 0)
	    rampBeats = 0;
    sampleBeat += rampBeats;
    StartClampBeat += rampBeats;
    StartControlBeat += rampBeats;
    StopControlBeat += rampBeats;

    // currient time in ms
    cycleStartTime = RT::OS::getTime() * 1e-6;

    setAmpMode("Iclamp");

    /*
     * Initialize the GUI
     */
    setState("BCLout", cycleLength);
    setState("beatNum", cycleNumber);
    setState("APDout", APDout);
    setState("rampBeats", rampBeats);
    setState("alternansMagnitude", alternansMagnitude);
    setState("shutterOPENBeat", shutterOPENBeat);
    setState("ControlGainOut", ControlGain);
    setState("RMBPout", RMBP);
    setParameter("controlGainAdaptation", controlGainAdaptation);
    setParameter("period1Threshold", period1Threshold);
    setParameter("period1Beats", period1Beats);
    setParameter("finalBCL", finalBCL);
    setParameter("RepolPercent", RepolPercent);
    setParameter("threshold", threshold);
    setParameter("ControlGain", ControlGain);
    setParameter("StartBCL", StartBCL);
    setParameter("finalBCL", finalBCL);
    setParameter("measuredRMBP", measuredRMBP);
    setParameter("rampStep", rampStep);
    setParameter("BeatsPerStep", BeatsPerStep);
    setParameter("StimMag", StimMag);
    setParameter("shutterOpenDuration", shutterOpenDuration);
    shutterOpenDuration*=1000;
    StimMag*=1e-9;
    setParameter("StimLength", StimLength);
    refresh();

}

stim::~stim(void) {
    setAmpMode("Iclamp"); 
}

//Gets called periodically in real time
void stim::execute(void) {

	// Set current time (in ms)
	time = RT::OS::getTime() * 1e-6;

	if (thresholdDetection) {
		V[1]=input(0);

		// applpy stimulus for given number of ms (StimLength)
		if (time-initialStimulusTime < StimLength) {
			backToBaseline=false;
			output(1) = stimulusLevel;
		}
		else {
			output(1) = 0.0;
			//if Vm is back to resting membrane potential (within 2 mV; determined when threshold detection button is first pressed)
			if (V[1]-Vrest < 0.001) {
				if (!backToBaseline) {
					responseDuration = time-initialStimulusTime;
					responseTime=time;
					backToBaseline=true;
				}
				// calculate how long the voltage response was
				// if the response was more than 50ms long, consider it an AP	
				if (responseDuration > 100) {
					// set the current stimulus value as the calculated threshold	
					diastolicThreshold=stimulusLevel;
					// stop the threshold detection test
					thresholdDetection=false;
				}
				// if no action potential occurred, and Vm is back to rest
				else {
					// if the cell has rested for 10ms since returning to baseline
					if (time-responseTime > 50) {
						// increase the magnitude of the stimulus and try again
						stimulusLevel+=0.2e-9;
						// record the time of stimulus application
						initialStimulusTime=time;
					}
				}
			}
		}
	}



	

	// if the "Pace" button is depressed
	if (pace) {
		
		if (time > shutterCloseTime) shutterOpen = false;
		toggleShutter(shutterOpen);

		// Instructions for end of each cycle
		if (time - cycleStartTime > cycleLength){

			// Advance the Beat
			cycleNumber++;
			cycleStartTime = time;
		
			// turn off experiments (unclick buttons) if they are finished:
			if ((int) cycleNumber == expt1FinishedBeat) {
				expt1InProgress = false;
				expt1Triggered=false;
				resetExptCounters();
			}
			if ((int) cycleNumber == expt2FinishedBeat) {
				expt2InProgress = false;
				expt2Triggered=false;
				resetExptCounters();
			}

			// Send 5V signal to camera at beginning of CameraBeat
			if (cycleNumber == CameraBeat)
				triggerCamera();
			
			// Open Fluorescent lamp shutter if in FluorBeats
			//if (cycleNumber >= shutterOPENBeat) {
//			if (cycleNumber >= shutterOPENBeat && time < shutterCloseTime) {
//				shutterOpen=true;
//			}
//			else {
//				shutterOpen = false;
//			}
	
		
			// Adjust BCL if still in ramping period
			if (cycleNumber <= rampBeats){
				rampBeatCount++;
				if (rampBeatCount==BeatsPerStep){
					rampBeatCount=0;
					cycleLength -= rampStep;}
				}
			// if not in the midst of a ramp, BCL=finalBCL
			else
				cycleLength = finalBCL;

			// if running a restitution protocol
			if (restitutionProtocol) {
				// if not done with the series of S1 beats
				if (curveBeat<numberS1Beats) {
					// BCL is the S1 BCL
					cycleLength=s1BCL;
				}
				// otherwise, you're at the S2 beat
				else {
					// set BCL to S2 BCL, advance next S2 BCL to
					// be even shorter (by the restInterval)
					cycleLength=s2BCL;
					s2BCL-=restInterval;
					curveBeat=0;
				}
				// if finished with the protocol...
				if (s2BCL<restStopBCL) {
					restitutionProtocol=false;
				}
	
				curveBeat++;
			}

			// if running a dynamic restitution protocol
			if (dynamicRestitution==true && dynamicStepNumber < dynamicMaximumSteps) {
				dynamicBeatNumber++;
				if (dynamicBeatNumber > dynamicBeatsPerStep) {
					dynamicStepNumber++;
					dynamicBeatNumber=0;
					//printf("cyclength changed to #%d%f\n", dynamicStepNumber, dynamicBCL[dynamicStepNumber]);
				}
				cycleLength=dynamicBCL[dynamicStepNumber];
			}

			// advance APDs
			APD[0]=APD[1];
			// Resting Membrane Potential set as voltage at the end of cycle
			if ((int) measuredRMBP==99999)
				RMBP = input(0);
			else
				RMBP = measuredRMBP / 1000;
			upstrokeThreshold = RMBP + threshold;	
			ClampCount=0;
			dVmax = 0;
			Vmax = -999;
			if (!expt1Triggered)
				sampleStep=0;
			apdMeasured=false;
	
		} // end of beat instructions
	
		// Turn off signal to camera, if it has reached set pulse length (1 ms)
		if (cameraRecording)
			if (time - cameraRecordingTime > 1)
				stopCameraTrigger();
	

		// record APs for when period-1 is reached:
		if (!expt1Triggered) {
			sampleV[aMagCount][sampleStep] = input(0);
			++sampleStep;
		}


		// New Voltage inputted from RTXI
		V[1] = input(0);

		// Defining upstroke by crossing of threshold-- RMP + threshold parameter
		if (V[1]>upstrokeThreshold && V[0]<upstrokeThreshold) 
			upstrokeTime = time;
		
		// Finding Vmax (for calculation of % repolarization)-- only take V as Vmax if it is 
		// greater than upstroke potential.  This is to avoid spurious APD 
		// calculations due to noise early on in each cycle.
		if (V[1] > Vmax)
			if (V[1] > upstrokeThreshold)
				Vmax = V[1];

		// Set repolarization condition based on RMBP and Vmax	
		Vrepol = Vmax - RepolPercent*(Vmax-RMBP);


		if ((int) round(cycleNumber) == StartControlBeat)
			alternansControl =true;
		if ((int) round(cycleNumber) == StopControlBeat)
			alternansControl =false;
		
		// If repol% repolarization is passed in the downward direction, define APD
		if (V[1] < Vrepol && V[0] >= Vrepol && time-upstrokeTime > 10) {


			// If APD has not bneen measured yet... (Flag prevents APD from being sampled multiple 
			// times if noise causes voltage to jump around repolarization threshold
			if (!(apdMeasured)){
			
				// APD is the time that's passed since the upstroke threshold
				// was passed
				APD[1]=time-upstrokeTime;
				APDout = APD[1] / 1000;
				apdMeasured=true;

				// advance record of alternans magnitudes for adaptive feedback algorithm
				theta[0]=theta[1];
				theta[1]=theta[2];
				theta[2]=theta[3];
				
				// moved from beginning of end of cycle instructions:
				// calculate alternans magnitude
				alternansMagnitude = (APD[1]-APD[0])/1000;
				if (alternansMagnitude < 0) {
					alternansMagnitude *= -1;
					theta[3]=1;
				}
				else theta[3]=0;

				// calculate average APD from last few beats (number of beats determined by $period1beats).
				// then determine which of the last five beats was closest to this average.  This will be the
				// AP that is used as a clamp when it's time to do so.
				if (!expt1Triggered) {
					previousAPD[aMagCount]=APD[1];
					apdSum=0;
					for (int ii=0; ii<period1Beats; ii++)
						apdSum+=previousAPD[ii];				
					previousAPDaverage=apdSum/period1Beats;
					closestAPD = 99999;
					for (int ii=0; ii<period1Beats; ii++) {
						if (fabs(previousAPD[ii]-previousAPDaverage) < closestAPD) {
							closestAPD = fabs(previousAPD[ii]-previousAPDaverage);
							closestAPDnumber = ii;	
						}
					}	
						
					//printf("beat %d, APD: %f, averageAPD: %f, closest to average is %d with APD of %f\n",
					//	(int)cycleNumber, APD[1], previousAPDaverage, closestAPDnumber, previousAPD[closestAPDnumber]);
				}
				//else
					//printf("period1 reached-- will clamp with sample number %d, APD=%f\n",
					//	closestAPDnumber, previousAPD[closestAPDnumber]);

				//  determine if the cell is near its period-1:
				aMagSum -= previousAlternansMagnitude[aMagCount];
				if (alternansMagnitude < period1Threshold)  previousAlternansMagnitude[aMagCount] = 1;
				else 		 		 previousAlternansMagnitude[aMagCount] = 0;
				aMagSum += previousAlternansMagnitude[aMagCount];				
				if (++aMagCount == (int) period1Beats) aMagCount=0;
				if (aMagSum == (int) period1Beats) period1Reached=true;
				else				period1Reached=false;

				// experiment 1 instructions:
				if (expt1InProgress && period1Reached && !expt1Triggered) {
					sprintf(exptInfoString, "%s\nperiod-1 reached (%dbts<%dms), beat %d", exptInfoString, (int) period1Beats, (int)(period1Threshold*1000), (int) cycleNumber);
					sampleBeat = cycleNumber + 1;
					StartClampBeat = cycleNumber + 2;
					StopControlBeat = cycleNumber + 2;
					CameraBeat = cycleNumber + 1;
					shutterOPENBeat = cycleNumber + 1;
					shutterOpen = true;
					shutterCloseTime = time + cycleLength + 9500;
					expt1Triggered = true;
					expt1FinishedBeat = (int) (cycleNumber + (9000 / finalBCL) + 10);
				}


				// experiment 2 instructions:	
				if (expt2InProgress && period1Reached && !expt2Triggered) {
					sprintf(exptInfoString, "%s\nperiod-1 reached (%dbts<%dms), beat %d", exptInfoString, (int) period1Beats, (int)(period1Threshold*1000), (int) cycleNumber);
					StopControlBeat = cycleNumber + 1;
					CameraBeat = cycleNumber + 1;
					shutterOPENBeat = cycleNumber + 1;
					shutterOpen = true;
					shutterCloseTime = time + cycleLength + 9500;
					expt2Triggered = true;
					expt2FinishedBeat = (int) (cycleNumber + (9000 / finalBCL) + 10);
				}

				// if alternans control is ON, calculate when to give the next 
				// stimulus (the cycle length), based on this APD
				if (alternansControl) {
					if (theta[0]==0 && theta[1]==1 && theta[2]==0 && theta[3]==1)
						ControlGain += controlGainAdaptation;
					else if (theta[0]==1 && theta[1]==0 && theta[2]==1 && theta[3]==0)
						ControlGain += controlGainAdaptation;
					else if (ControlGain - controlGainAdaptation > 0)
						ControlGain -= controlGainAdaptation;
					// one-sided control:
					//if (theta[3]==1)	
					cycleLength = finalBCL + (ControlGain/2)*(APD[1]-APD[0]);
					//printf("alternans control-- finalBCL: %.2f, controlGain: %.2f, APD[1]: %.2f, APD[0]:%.2f, cycleLength: %.2f\n",
					//	finalBCL, ControlGain/2, APD[1], APD[0], cycleLength);
				}
			}
		}  // end repolarization instructions
		
		//  Determining if voltage or current clamping:
		//  if past StarClampBeat,  set amplifier to voltage clamp mode, and apply sampled waveform
		if ((int) round(cycleNumber) >= StartClampBeat && expt1InProgress){
			// stimulus (through Istim) = 0
			output(1) = 0;

			// if it's the first clamped beat, set the amplifier to the right mode.
			if (round(cycleNumber) == StartClampBeat && ClampCount == 0) {
				setAmpMode("Vclamp");
				// so that the nds recorded records the APD of the clamped beat, not simply the APD of
				// the last beat before switching.
				APDout=previousAPD[closestAPDnumber]/1000;
			}

			// Set cycle length during clamping to the BCL of interest, regardless of the BCL of the voltage
			// waveform-- Pad the end of the sampled AP if it's shorter than the BCL
			cycleLength = finalBCL;
			if (ClampCount <= sampleStep -1)  
				output(0) = sampleV[closestAPDnumber][ClampCount];
			else 
				output(0) = sampleV[closestAPDnumber][sampleStep-1];

			// advance clamp count
			ClampCount++;
		}
		//  If not past StartClampBeat, set amplifier to current clamp mode, and apply current stimulus
		//  for prescribed length (StimLength).
		else {

			if (AMAmpCommander::Plugin::getInstance()->getAmplifier()->getMode() != AMAmpCommander::Amplifier::Iclamp)
				if ((int) cycleNumber == expt1FinishedBeat) 
					setAmpMode("Izero");
				else
					setAmpMode("Iclamp");
			
	
			// stimulus (through Vout) = 0
			output(0) = 0;
	
			// for the first X ms of each cycle, apply a Y Ampere stimulus, where X=stimLength
			// and Y=stimMag
			if (time - cycleStartTime <= StimLength)  
				output(1) = StimMag;
			else  
				output(1) = 0;
		}
	
		// Advance voltage
		V[0] = V[1];
	
	} // end of "pace" instructions

}

void stim::update(stim::update_flags_t flag) {



	if(flag == PAUSE) {
		toggleShutter(false);
		togglePace(false);
		toggleThresholdTest(false);
		toggleControl(false);
		toggleExp1(false);
		toggleExp2(false);
	}

	if (flag == CONTROLON) {
		alternansControl = true;
		if (!pauseButton->isOn())
			sprintf(exptInfoString, "%s\ncontrol ON: beat %.0f", exptInfoString, cycleNumber);
	}
	if (flag == CONTROLOFF) {
		alternansControl = false; 
		if (!pauseButton->isOn()) {
			if (expt1InProgress || expt2InProgress)
				sprintf(exptInfoString, "%s\ncontrol OFF: beat %.0f", exptInfoString, StopControlBeat);
			else
				sprintf(exptInfoString, "%s\ncontrol OFF: beat %.0f", exptInfoString, round(cycleNumber));
		}
	}

	if (flag == STARTEXP1)  {
		// sample beat n+9, and then clamp with that waveform from n+10 on.  Trigger camera
		// to begin recording immediately (should be set for 18 seconds recording), and open
		// shutter 5 beats before control is turned OFF.  keep shutter open for 20 beats after
		// control is turned OFF.
		expt1InProgress=true;
		expt1Triggered=false;
		if (!pauseButton->isOn())
			sprintf(exptInfoString, "%s\nclamp expt: beat %.0f", exptInfoString, cycleNumber);
	}
	
	if (flag == STOPEXP1) {
		expt1InProgress=false;
		expt1Triggered=false;
	}

	if (flag == STARTEXP2)  {
		// Free pacing protocol:  turn OFF control in 10 beats.  Trigger camera
		// to begin recording immediately (should be set for 18 seconds recording), and open
		// shutter 5 beats before control is turned OFF.  keep shutter open for 20 beats after
		// control is turned OFF.
		expt2InProgress=true;
		expt2Triggered=false;
		if (!pauseButton->isOn())
			sprintf(exptInfoString, "%s\npace expt: beat %.0f", exptInfoString, cycleNumber);
	}

	if (flag == STOPEXP2) {
		expt2InProgress=false;
		expt2Triggered=false;
	}

	if (flag == STARTCAMERA) {
		if (!pauseButton->isOn()) {
			shutterOpen=true;
			// if there's less than 30ms less in this cycle, wait until the next beat to trigger the
			// camera (to ensure the shutter is completely open when recording starts).
			if (time-cycleStartTime > cycleLength-30)	
				CameraBeat = cycleNumber + 2;
			else
				CameraBeat = cycleNumber + 1;
			shutterOPENBeat = cycleNumber + 1;
			shutterCloseTime = time + cycleLength + shutterOpenDuration;//20000;
			sprintf(exptInfoString, "%s\nshutter/camera ON: beat %.0f", exptInfoString, cycleNumber);
		}
	}

	if (flag == STOPCAMERA) {
		if (!pauseButton->isOn()) {
			shutterOpen=false;
			shutterCloseTime = 0;
			sprintf(exptInfoString, "%s\nshutter/camera OFF: beat %.0f", exptInfoString, cycleNumber);
		}
	}		

	if (flag == STARTEXP4) {
		alternansControl=false;
		dynamicRestitution = true;
		dynamicBeatNumber=0;
		dynamicStepNumber=0;
		dynamicBeatsPerStep=50;
		dynamicMaximumSteps=15;
		dynamicBCL[0]=500;
		dynamicBCL[1]=480;
		dynamicBCL[2]=460;
		dynamicBCL[3]=440;
		dynamicBCL[4]=420;
		dynamicBCL[5]=400;
		dynamicBCL[6]=380;
		dynamicBCL[7]=360;
		dynamicBCL[8]=350;
		dynamicBCL[9]=340;
		dynamicBCL[10]=330;
		dynamicBCL[11]=320;
		dynamicBCL[12]=310;
		dynamicBCL[13]=300;
		dynamicBCL[14]=290;
		dynamicBCL[15]=280;
		if (!pauseButton->isOn())
			sprintf(exptInfoString, "%s\ndyn. rest: beat %.0f", exptInfoString, cycleNumber);
	}
	
	if(flag == MODIFY)
		reacquireParameters();
  
	if (flag == UNPAUSE){
		exptInfoLabel->clear();
		sprintf(exptInfoString, "");
		reacquireParameters();	
		resetVariables();
		toggleShutter(false);
		setAmpMode("Iclamp");
		refresh();
	}

}



void stim::setAmpMode( const char* mode ) {

	QString modeLabelString;

	if (strcmp( mode, "Iclamp")) {
		modeLabelString.sprintf( "Vclamp" );
		AMAmpCommander::Plugin::getInstance()->getAmplifier()->setMode(AMAmpCommander::Amplifier::Vclamp);		
	}
	else {
		modeLabelString.sprintf( "Iclamp" );
		AMAmpCommander::Plugin::getInstance()->getAmplifier()->setMode(AMAmpCommander::Amplifier::Iclamp);		
	}
	ModeLabel->setText(modeLabelString);
}


void stim::exit(void) {
    update(EXIT);
    Plugin::Manager::getInstance()->unload(this);
}

void stim::refresh(void) {
    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i) {
        if(i->second.type & (STATE | EVENT))
            i->second.edit->setText(QString::number(getValue(i->second.type,i->second.index)));
        else if((i->second.type & PARAMETER) && !i->second.edit->edited() && i->second.edit->text() != *i->second.str_value)
            i->second.edit->setText(*i->second.str_value);
    }
    pauseButton->setOn(!getActive());
    controlButton->setOn(alternansControl);
    cameraButton->setOn(shutterOpen);
    toggleExp1Button->setOn(expt1InProgress);
    toggleExp2Button->setOn(expt2InProgress);

    // update the threshold label, if the test is over, and a threshold was found.
    if (diastolicThreshold>0)
	toggleThresholdTest(false);

    QString exptInfoLabelString;
    exptInfoLabelString.sprintf(exptInfoString);	
    exptInfoLabel->setText(exptInfoLabelString);    
}

void stim::modify(void) {
    bool active = getActive();

    setActive(false);

    // Ensure that the realtime thread isn't in the middle of executing stim::execute()
    SyncEvent event;
    RT::System::getInstance()->postEvent(&event);

    update(MODIFY);
    setActive(active);

    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i)
        i->second.edit->blacken();
}

void stim::toggleExp1(bool p) {
    bool active = getActive();

    setActive(false);

    if(toggleExp1Button->isOn() != p)
        toggleExp1Button->setDown(p);

    toggleExp1Button->setOn(p);

    // Ensure that the realtime thread isn't in the middle of executing stim::execute()
    SyncEvent event;
    RT::System::getInstance()->postEvent(&event);

    if(p)
        update(STARTEXP1);
    else
        update(STOPEXP1); 

    setActive(active);

    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i)
        i->second.edit->blacken();
}


void stim::toggleExp2(bool p) {
    bool active = getActive();

    setActive(false);

    if(toggleExp2Button->isOn() != p)
        toggleExp2Button->setDown(p);

    toggleExp2Button->setOn(p);

    // Ensure that the realtime thread isn't in the middle of executing stim::execute()
    SyncEvent event;
    RT::System::getInstance()->postEvent(&event);

    if(p)
        update(STARTEXP2);
    else
        update(STOPEXP2); 

    setActive(active);

    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i)
        i->second.edit->blacken();
}

void stim::toggleCameraButton(bool p) {
    bool active = getActive();

    setActive(false);

    if(cameraButton->isOn() != p)
        cameraButton->setDown(p);

    cameraButton->setOn(p);
    // Ensure that the realtime thread isn't in the middle of executing stim::execute()
    SyncEvent event;
    RT::System::getInstance()->postEvent(&event);

    if (p) 
	    update(STARTCAMERA);
    else
            update(STOPCAMERA);

    setActive(active);

    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i)
        i->second.edit->blacken();
}

void stim::startExp4(void) {
    bool active = getActive();

    setActive(false);

    // Ensure that the realtime thread isn't in the middle of executing stim::execute()
    SyncEvent event;
    RT::System::getInstance()->postEvent(&event);

    update(STARTEXP4);
    setActive(active);

    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i)
        i->second.edit->blacken();
}

QString stim::getParameter(const QString &name) {
    std::map<QString,param_t>::iterator n = parameter.find(name);
    if((n != parameter.end()) && (n->second.type & PARAMETER)) {
        *n->second.str_value = n->second.edit->text();
        *n->second.value = n->second.edit->text().toDouble();
        return n->second.edit->text();
    }
    return "";
}

void stim::setParameter(const QString &name,double value) {
    std::map<QString,param_t>::iterator n = parameter.find(name);
    if((n != parameter.end()) && (n->second.type & PARAMETER)) {
        n->second.edit->setText(QString::number(value));
        *n->second.str_value = n->second.edit->text();
        *n->second.value = n->second.edit->text().toDouble();
    }
}

void stim::setParameter(const QString &name,const QString value) {
    std::map<QString,param_t>::iterator n = parameter.find(name);
    if((n != parameter.end()) && (n->second.type & PARAMETER)) {
        n->second.edit->setText(value);
        *n->second.str_value = n->second.edit->text();
        *n->second.value = n->second.edit->text().toDouble();
    }
}

void stim::setState(const QString &name,double &ref) {
    std::map<QString,param_t>::iterator n = parameter.find(name);
    if((n != parameter.end()) && (n->second.type & STATE)) {
        setData(Workspace::STATE,n->second.index,&ref);
        n->second.edit->setText(QString::number(ref));
    }
}

void stim::setEvent(const QString &name,double &ref) {
    std::map<QString,param_t>::iterator n = parameter.find(name);
    if((n != parameter.end()) && (n->second.type & EVENT)) {
        setData(Workspace::EVENT,n->second.index,&ref);
        n->second.edit->setText(QString::number(ref));
    }
}

void stim::pause(bool p) {
    if(pauseButton->isOn() != p)
        pauseButton->setDown(p);

    setActive(!p);
    if(p)
        update(PAUSE);
    else
        update(UNPAUSE);
}

void stim::toggleControl(bool p) {
    bool active = getActive();
   
    setActive(false);

    if(controlButton->isOn() != p)
        controlButton->setDown(p);

    controlButton->setOn(p);

    // Ensure that the realtime thread isn't in the middle of executing stim::execute()
    SyncEvent event;
    RT::System::getInstance()->postEvent(&event);

    if(p)
        update(CONTROLON);
    else
        update(CONTROLOFF); 

    setActive(active);
}

void stim::toggleThresholdTest(bool p) {

    	bool active = getActive();

	if (active) {
		setActive(false);
		
		// Ensure that the realtime thread isn't in the middle of executing stim::execute()
		SyncEvent event;
		RT::System::getInstance()->postEvent(&event);
	
		QString thresholdLabelString;
	
		setAmpMode("Iclamp");
	
		if (thresholdTestButton->isOn() != p) {
			thresholdTestButton->setDown(p);
			thresholdTestButton->setOn(p);
		}
	
		if(p) {
			togglePace(false);
			diastolicThreshold = -1;
			thresholdDetection=true;
			stimulusLevel=1e-9;	
			Vrest=input(0);
			initialStimulusTime=RT::OS::getTime() * 1e-6;
	    	}
		else 
			thresholdDetection=false;
	
	
		if (thresholdTestButton->isOn())
			thresholdLabelString.sprintf( "calculating threshold..." );
		else {
			if (diastolicThreshold>0)
				thresholdLabelString.sprintf( "threshold: %.2fnA, 2x = %.2fnA", diastolicThreshold*1e9, 2*diastolicThreshold*1e9);
			else
				thresholdLabelString.sprintf( "--" );
		}

		thresholdLabel->setText(thresholdLabelString);
	
	    	setActive(active);
	}
}

void stim::togglePace(bool p) {

    	bool active = getActive();

	setActive(false);

	// Ensure that the realtime thread isn't in the middle of executing stim::execute()
	SyncEvent event;
	RT::System::getInstance()->postEvent(&event);

	setAmpMode("Iclamp");
	reacquireParameters();
	resetVariables();
	toggleShutter(false);
	refresh();

	if (paceButton->isOn() != p) {
		paceButton->setDown(p);
		paceButton->setOn(p);
	}
	
	if (p) {
		pace=true;
		toggleThresholdTest(false);	
	}
	else
		pace=false;

	setActive(active);
}

void stim::doLoad(const Settings::Object::State &s) {
    for(std::map<QString,param_t>::iterator i = parameter.begin();i != parameter.end();++i)
        i->second.edit->setText(s.loadString(i->first));
    pauseButton->setOn(s.loadInteger("paused"));
    modify();
}

void stim::doSave(Settings::Object::State &s) const {
    s.saveInteger("paused",pauseButton->isOn());
    for(std::map<QString,param_t>::const_iterator i = parameter.begin();i != parameter.end();++i)
        s.saveString(i->first,i->second.edit->text());
}

void stim::receiveEvent(const Event::Object *event) {
    if(event->getName() == RT::System::PRE_PERIOD_EVENT) {
        periodEventPaused = getActive();
        setActive(false);
    } else if(event->getName() == RT::System::POST_PERIOD_EVENT) {
#ifdef DEBUG
        if(getActive())
            ERROR_MSG("stim::receiveEvent : model unpaused during a period update\n");
#endif
        update(PERIOD);
        setActive(periodEventPaused);
    }
}


DefaultGUILineEdit::DefaultGUILineEdit(QWidget *parent)
    : QLineEdit(parent) {
    QObject::connect(this,SIGNAL(textChanged(const QString &)),this,SLOT(redden(void)));
}

DefaultGUILineEdit::~DefaultGUILineEdit(void) {}

void DefaultGUILineEdit::blacken(void) {
    setPaletteForegroundColor(Qt::black);
    setEdited(false);
}

void DefaultGUILineEdit::redden(void) {
    if(edited())
        setPaletteForegroundColor(Qt::red);
}

void stim::triggerCamera(){
	cameraRecording = true;
	output(2) = 5;
	cameraRecordingTime = RT::OS::getTime() * 1e-6;
};

void stim::stopCameraTrigger() {
	output(2) = 0;
	cameraRecording = false;
};

void stim::reacquireParameters() {
	ControlGain = getParameter("ControlGain").toDouble();
	period1Threshold = getParameter("period1Threshold").toDouble();
	period1Beats = getParameter("period1Beats").toDouble();
	controlGainAdaptation = getParameter("controlGainAdaptation").toDouble();
	RepolPercent = getParameter("RepolPercent").toDouble();
	threshold = getParameter("threshold").toDouble();
	StimLength = getParameter("StimLength").toDouble();
	StimMag = getParameter("StimMag").toDouble();
    	StimMag*=1e-9;
	shutterOpenDuration = getParameter("shutterOpenDuration").toDouble() * 1000;
	StartBCL = getParameter("StartBCL").toDouble();
	finalBCL = getParameter("finalBCL").toDouble();
	measuredRMBP = getParameter("measuredRMBP").toDouble();
	rampStep = getParameter("rampStep").toDouble();
	BeatsPerStep = getParameter("BeatsPerStep").toDouble();

	// reset ramping protocol
    	rampBeats = BeatsPerStep * ((StartBCL-finalBCL) / rampStep);
	if (rampBeats < 0)
	    rampBeats = 0;
	rampBeatCount = 0;	
}

void stim::resetVariables() {

	// Reset times and BCL
	cycleStartTime = RT::OS::getTime() * 1e-6;
	cycleLength = StartBCL;

	// Reset Counters
	cycleNumber =0;    
	sampleStep=0;
	ClampCount=0;
	APD[1] = 0;
	apdMeasured = false;
	theta[0]=0;
	theta[1]=0;
	theta[2]=0;
	theta[3]=0;
	dVmax = 0;
    	Vmax = -999;

	cameraRecording=false;
	shutterOpen=false;
	restitutionProtocol=false;
	dynamicRestitution=false;
    	for (int ii=0; ii<20; ii++) previousAlternansMagnitude[ii]=0;

	expt1InProgress=false;
	expt1Triggered=false;
	expt2InProgress=false;
	expt2Triggered=false;
	aMagSum = 0;
	aMagCount = 0;
	alternansControl=false;

	resetExptCounters();
}

void stim::resetExptCounters() {

    	StartClampBeat=999999;
	StartControlBeat=999999;
	StopControlBeat=999999;
	shutterOPENBeat = 99999;
    	shutterCloseTime = 0;
	CameraBeat=99999;

}
	
