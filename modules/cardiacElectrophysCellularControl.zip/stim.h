/*
 * Copyright (C) 2004 Boston University
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <qobject.h>
#include <qwidget.h>
#include <event.h>
#include <map>
#include <mutex.h>
#include <plugin.h>
#include <qlineedit.h>
#include <qtextedit.h>
#include <rt.h>
#include <workspace.h>

#include <default_gui_model.h>

#define Delta 0.0001

class QLabel;
class QPushButton;


class stim : public QWidget, public RT::Thread, public Plugin::Object, public Workspace::Instance, public Event::Handler
{

    Q_OBJECT

public:

    static const IO::flags_t INPUT     = Workspace::INPUT;
    static const IO::flags_t OUTPUT    = Workspace::OUTPUT;
    static const IO::flags_t PARAMETER = Workspace::PARAMETER;
    static const IO::flags_t STATE     = Workspace::STATE;
    static const IO::flags_t EVENT     = Workspace::EVENT;
    static const IO::flags_t DOUBLE    = Workspace::EVENT<<1;
    static const IO::flags_t INTEGER   = Workspace::EVENT<<2;
    static const IO::flags_t UINTEGER  = Workspace::EVENT<<3;
    typedef Workspace::variable_t variable_t;
    enum update_flags_t {
        INIT,     /*!< The parameters need to be initialized.         */
        MODIFY,   /*!< The parameters have been modified by the user. */
        PERIOD,   /*!< The system period has changed.                 */
        PAUSE,    /*!< The Pause button has been activated            */
        UNPAUSE,  /*!< When the pause button has been deactivated     */
	STARTEXP1,
	STOPEXP1,
	STARTEXP2,
	STOPEXP2,
	STARTCAMERA,
	STOPCAMERA,
	STARTEXP4,
	CONTROLON,
	CONTROLOFF,
        EXIT,     /*!< When the module has been told to exit        */
    };
    stim(void);
    virtual ~stim(void);
    void execute(void);
//    virtual void update(update_flags_t flag);
	
public slots:

    void exit(void);
    void refresh(void);
    void modify(void);
    void toggleExp1(bool);
    void toggleExp2(bool);
//    void startExp3(void);
    void startExp4(void);
    void toggleControl(bool);
    void pause(bool);	
    void toggleThresholdTest(bool);
    void togglePace(bool);
    void toggleCameraButton(bool);
	
protected:

    void update(stim::update_flags_t);
    QString getParameter(const QString &name);
    void setParameter(const QString &name,double value);
    void setParameter(const QString &name,const QString value);
    void setState(const QString &name,double &ref);
    void setEvent(const QString &name,double &ref);

private:

    // Functions:
    void setAmpMode( const char* );
    void doLoad(const Settings::Object::State &);
    void doSave(Settings::Object::State &) const;
    void receiveEvent(const Event::Object *);	
    void toggleShutter(bool open) {
	if (open) output(3) = 5.0;
	else output(3) = 0.0;
    }
    void triggerCamera();
    void stopCameraTrigger();
    void reacquireParameters();
    void resetVariables();
    void resetExptCounters();

    double ControlGain, finalBCL, cycleStartTime, cycleLength, cameraRecordingTime, LightDuration;
    double StartBCL, StimMag, StimLength, cycleNumber, RMBP, RepolPercent, thresholdOffset,  CameraBeat;
    double rampStep, BeatsPerStep, StartFlag;
    double upstrokeThreshold, threshold;
    double dVmax, upstrokeTime, V[2], Vmax, Vrepol, APD[3], APD_time, alternansMagnitude, rampBeats;
    double APDout;
    double shutterCloseTime;

    double sampleV[10][99999];
    int sampleStep;
    double apdSum, previousAPDaverage, closestAPD;
    int closestAPDnumber;
    double previousAPD[10];
    bool clamping;

    int theta[4];
    double controlGainAdaptation;
    bool apdMeasured;
    bool cameraRecording;
    bool pace;
    bool dynamicRestitution;
    double measuredRMBP;

    double time;

    // Dynamic restitution expt variables
    int dynamicStepNumber;
    int dynamicBeatNumber;
    int dynamicBeatsPerStep;
    int dynamicMaximumSteps;
    double dynamicBCL[100]; 

    // general experimental variables
    int rampBeatCount;
    int ClampCount;
    double  StartControlBeat, StopControlBeat;
    double shutterOPENBeat;
    double sampleBeat, StartClampBeat;
    double shutterOpenDuration;
    int previousAlternansMagnitude[20];
    bool alternansControl;
    bool expt1InProgress, expt1Triggered;
    bool expt2InProgress, expt2Triggered;
    bool period1Reached;
    double period1Threshold, period1Beats;
    int aMagCount, aMagSum;
    int expt2FinishedBeat;
    int expt1FinishedBeat;
    bool shutterOpen;

    // threshold detector
    bool thresholdDetection;
    bool actionPotential;
    bool thresholdStimulate;
    bool backToBaseline;
    double stimulusLevel;
    double startingStimulusLevel;
    double Vrest;
    double responseTime, initialStimulusTime;
    double diastolicThreshold;
    double responseDuration;

    // S1S2 expt variables
    int s1BCL, s2BCL, restStopBCL;
    int numberS1Beats;
    int restInterval;
    int curveBeat;
    bool restitutionProtocol;

    // this is not set up to actually work yet.
    void triggerDataRecorder() {output(4)=5;};
    void dataRecorderOff() {output(4)=0;};

    struct param_t {
	QLabel *label;
	DefaultGUILineEdit *edit;
	IO::flags_t type;
	size_t index;
	QString *str_value;
	double *value;
   };

	
   bool periodEventPaused;
   mutable QString junk;
   std::map<QString, param_t> parameter;


   // QT components
   QPushButton *thresholdTestButton;
   QPushButton *pauseButton;
   QPushButton *controlButton;
   QPushButton *paceButton;
   QPushButton *toggleExp2Button;
   QPushButton *toggleExp1Button;
   QPushButton *cameraButton;
   QLabel *ModeLabel;
   QLabel *thresholdLabel;
   QLabel *exptLabel;
   QLabel *modeHeader;
   QLabel *pluginControlHeader;
   QLabel *exptModeHeader;

   QTextEdit *exptInfoLabel;

   char exptInfoString[1000];



};
